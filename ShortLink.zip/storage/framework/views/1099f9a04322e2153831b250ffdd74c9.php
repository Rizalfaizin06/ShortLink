

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">Dashboard</div>
        <div class="card-body">
            <h5 class="card-title">Selamat datang, <?php echo e(Auth::user()->name); ?>!</h5>
            <p class="card-text">Ini adalah dashboard URL Shortener Anda.</p>

            <div class="row mt-4">
                <div class="col-md-4">
                    <div class="card bg-light mb-3">
                        <div class="card-body text-center">
                            <h5 class="card-title">Link URLs</h5>
                            <p class="card-text">Kelola tautan pendek Anda.</p>
                            <a href="<?php echo e(route('links.index')); ?>" class="btn btn-primary">Kelola Link</a>
                        </div>
                    </div>
                </div>

                <?php if(Auth::user()->role_id === 1): ?>
                    <div class="col-md-4">
                        <div class="card bg-light mb-3">
                            <div class="card-body text-center">
                                <h5 class="card-title">Users</h5>
                                <p class="card-text">Kelola pengguna sistem.</p>
                                <a href="<?php echo e(route('users.index')); ?>" class="btn btn-primary">Kelola Users</a>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>

                <div class="col-md-4">
                    <div class="card bg-light mb-3">
                        <div class="card-body text-center">
                            <h5 class="card-title">Buat Link Baru</h5>
                            <p class="card-text">Buat tautan pendek baru.</p>
                            <a href="<?php echo e(route('links.create')); ?>" class="btn btn-success">Buat Link</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\PROJECT\ShortLink\resources\views/dashboard.blade.php ENDPATH**/ ?>